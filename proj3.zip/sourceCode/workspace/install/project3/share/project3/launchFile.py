from launch import LaunchDescription
from launch.actions import *
from launch.event_handlers import *
from launch.events import Shutdown
from launch_ros.actions import Node
from launch.substitutions import *



def generate_launch_description():

    bag_in = LaunchConfiguration('bag_in')
    bag_out = LaunchConfiguration('bag_out')

    # nodes
    publisher_node = Node(
        package='project3',
        namespace='publiser',
        executable='publisher_node',
        name='sim'
    )
    radar_subscriber = Node(
        package='project3',
        namespace='radar',
        executable='radar_subscriber',
        name='sim'
    )

    # bag play starting and ending process
    run_bag = ExecuteProcess(
        cmd=[[
            FindExecutable(name='ros2'),
            ' bag play ',
            bag_in
        ]],
        shell=True
    )
    start_bag = OnProcessStart(
        target_action=radar_subscriber,
        on_start=[
            run_bag
        ]
    )
    close_bag = OnProcessExit(
        target_action=run_bag,
        on_exit=[
            EmitEvent(event=Shutdown(
                reason='Window closed'))
        ]
    )

    # recording the bag
    record_bag = ExecuteProcess(
        cmd=[[
            FindExecutable(name='ros2'),
            ' bag record -a -o ',
            bag_out
        ]],
        shell=True
    )
    start_recording = OnProcessStart(
        target_action = publisher_node,
        on_start=[record_bag]
    )

    # returning the launch description
    return LaunchDescription([
        publisher_node,
        radar_subscriber,
        RegisterEventHandler(start_recording),
        RegisterEventHandler(start_bag),
        RegisterEventHandler(close_bag)
        
    ])
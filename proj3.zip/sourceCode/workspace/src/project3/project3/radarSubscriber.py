import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import numpy as np

RANGE_OUT_OF_BOUNDS = 6.0
CONSIDERATION_THRESHOLD = 0.8
WALL_ADJUSTMENT_THRESHOLD = 4
OBJECT_CONSIDERATION_THRESHOLD = 4

class LaserScanSubscriber(Node):
    def __init__(self):
        super().__init__('laser_scan_subscriber')
        self.subscription = self.create_subscription(
            LaserScan,
            'scan',
            self.scan_callback,
            10)
        self.wallPublisher = self.create_publisher(LaserScan, 'wallCoordinates', 10)
        self.locationPublisher = self.create_publisher(LaserScan, 'confirmedCoordiantes', 10)
        self.wallPublisherData = LaserScan()
        self.locationPublisherData = LaserScan()
        
        self.wallCoordinates = None
        self.wallAdjustment = None
        
        self.potentialObject = None
        self.confirmedObject = None

        
    def scan_callback(self, msg):
        
        # Converting nan, inf, and other exceptions to a set value to be ignored and initializa lists
        currentRanges = [r if 0.1 < r < 5.5 else RANGE_OUT_OF_BOUNDS for r in msg.ranges]
        if self.wallCoordinates is None:
            self.wallCoordinates = currentRanges
            self.potentialObject = [0.0]*len(self.wallCoordinates)
            self.confirmedObject = [0.0]*len(self.wallCoordinates)
            
            self.wallAdjustment = []
            for i in range(len(self.wallCoordinates)):
                self.wallAdjustment.append([0.0, 0])

            self.wallPublisherData = msg
            self.locationPublisherData = msg
            return
        
        # Calculating the differences in range from past measurements
        rangeDifference = [(self.wallCoordinates[i] - currentRanges[i]) for i in range(len(currentRanges))]       
        
        # If an object to closer than wall store as potential object for consideration
        self.potentialObject = [r if r > CONSIDERATION_THRESHOLD else 0 for r in rangeDifference]
       
        # If an object is further away perform check to see if wall needs 
        # to be adjusted. If there are multiple consecutive measurements of walls
        # being futher than expected of wallCoordiantes
        for i in range(len(currentRanges)):
            
            if (self.wallCoordinates[i] - currentRanges[i]) < (-CONSIDERATION_THRESHOLD):
                
                if self.wallAdjustment[i][1] <= 0.0:
                    self.wallAdjustment[i][1] += 1
                    self.wallAdjustment[i][0] = currentRanges[i]
                    
                # Check if new wall consideration is also a constant value
                if (abs(self.wallAdjustment[i][0] - currentRanges[i]) < 0.1):
                    self.wallAdjustment[i][1] += 1
                    
                    # If greater than threashold move wall
                    if self.wallAdjustment[i][1] >= WALL_ADJUSTMENT_THRESHOLD:
                        
                        self.wallCoordinates[i] = self.wallAdjustment[i][0]
                        self.wallAdjustment[i][1] = 0.0
                        continue
                    
                    continue
        
            # Reset otherwise
            self.wallAdjustment[i][0] = 0.0  
            self.wallAdjustment[i][1] = 0.0  
            
        # Update wall coordinates
        self.wallPublisherData.ranges = self.wallCoordinates
        self.wallPublisherData.header = msg.header
        self.wallPublisher.publish(self.wallPublisherData)
        
        
        # Detection of Objects
        for i in range(3, len(self.potentialObject) - 3):
            positiveCounter = 0
            
            # Check surroundings and if there are consecutive points it is considered a confirmed object
            for j in range(-OBJECT_CONSIDERATION_THRESHOLD, OBJECT_CONSIDERATION_THRESHOLD):
                if self.potentialObject[i+j] > 0.0:
                    positiveCounter += 1
            
            if positiveCounter >= OBJECT_CONSIDERATION_THRESHOLD * 2:
                self.confirmedObject[i] = 1.0
                continue
            self.confirmedObject[i] = 0.0
            
        # Find the center of confired objects
        counter = 0
        for i in range(len(self.confirmedObject)):
            
            # Add back real distance from camera
            if (counter > 0) and (self.confirmedObject[i] == 0.0):
                self.confirmedObject[i - int(counter/2)] = currentRanges[i - int(counter/2)]
                counter = 0
                
            if self.confirmedObject[i] == 1:
                self.confirmedObject[i] = 0.0
                counter += 1
                
        
        # Send Publisher Data
        self.locationPublisher.header = msg.header
        self.locationPublisherData.ranges = self.confirmedObject
        self.locationPublisher.publish(self.locationPublisherData)
            
        #print(self.locationPublisher.header)

        
        
def main(args=None):
    rclpy.init(args=args)

    laser_scan_subscriber = LaserScanSubscriber()

    try:
        while rclpy.ok():
            rclpy.spin_once(laser_scan_subscriber)
    except KeyboardInterrupt:
        pass

    laser_scan_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, PointCloud
from geometry_msgs.msg import Point32
from example_interfaces.msg import Int64
from math import sin, cos, dist

TOO_CLOSE = 0.3

class LaserScanToCoordinates(Node):
    def __init__(self):
        super().__init__('scan_to_coordinates')
        self.subscription = self.create_subscription(LaserScan, 'confirmedCoordiantes', self.scan_callback, 10)
        
        self.cloudPublisher = self.create_publisher(PointCloud, 'person_locations', 10)
        self.peopleNowCounterPublisher = self.create_publisher(Int64, 'people_count_current', 10)
        self.peopleTotalCounterPublisher = self.create_publisher(Int64, 'people_count_total', 10)
        self.currentPeople = Int64()
        self.totalPeople = Int64()
        self.lastCurrentPeople = 0
        self.totalPeopleInt = 0

    def scan_callback(self, msg):
        
        pc = PointCloud()
        lastX = 0.0
        lastY = 0.0
        for i, r in enumerate(msg.ranges):
            newPoint = Point32()
            
            # Convert angle and distance to x y coordinates
            # If two points are close together assume it is bugged
            if r != 0.0:
                newPoint.x = r * cos(msg.angle_min + i * msg.angle_increment)
                newPoint.y = r * sin(msg.angle_min + i * msg.angle_increment)
                newPoint.z = 0.0
                
                if (dist([newPoint.x, newPoint.y], [lastX, lastY]) < TOO_CLOSE):
                    continue
                
                pc.points.append(newPoint)
                lastX = newPoint.x
                lastY = newPoint.y

        
        pc.header = msg.header   
        self.cloudPublisher.publish(pc)


        # Counting current people
        currentPeople = 0
        
        newPerson = True
        for i, r in enumerate(msg.ranges):
            
            if r!= 0.0:
                currentPeople += 1
                
                
        # See if a new entry
        if currentPeople > self.lastCurrentPeople:
            self.totalPeopleInt += 1
                
        self.lastCurrentPeople = currentPeople
            
        
                
        self.previousLaserScan = msg.ranges
        self.currentPeople.data = currentPeople
        self.totalPeople.data = self.totalPeopleInt
        self.peopleNowCounterPublisher.publish(self.currentPeople)
        self.peopleTotalCounterPublisher.publish(self.totalPeople)



def main(args=None):
    rclpy.init(args=args)

    laser_scan_subscriber = LaserScanToCoordinates()

    try:
        while rclpy.ok():
            rclpy.spin_once(laser_scan_subscriber)
    except KeyboardInterrupt:
        pass

    laser_scan_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()